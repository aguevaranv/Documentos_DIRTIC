# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Artista(models.Model):
    _name = 'prueba.artista'
    _description = 'prueba.artista'

    name = fields.Char()
