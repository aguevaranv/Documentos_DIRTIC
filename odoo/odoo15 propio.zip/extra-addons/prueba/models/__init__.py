# -*- coding: utf-8 -*-


from . import prueba_pelicula
from . import prueba_prueba
from . import prueba_genero
from . import prueba_artista