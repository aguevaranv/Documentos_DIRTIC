# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Prueba(models.Model):
    _name = 'prueba.prueba'
    _description = 'prueba.prueba'

    name = fields.Char()
    cantidad = fields.Integer()
    precio = fields.Float(compute="_value_pc", store=True)
    # description = fields.Text()
