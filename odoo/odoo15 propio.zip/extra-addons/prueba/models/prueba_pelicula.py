# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Pelicula(models.Model):
    _name = 'prueba.pelicula'
    _description = 'prueba.pelicula'

    name = fields.Char()
    cantidad = fields.Integer()
    precio = fields.Float(compute="_value_pc", store=True)
    descripcion = fields.Text()
