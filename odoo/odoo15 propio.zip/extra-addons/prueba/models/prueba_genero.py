# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Genero(models.Model):
    _name = 'prueba.genero'
    _description = 'prueba.genero'

    name = fields.Char()
    cantidad = fields.Integer()
    precio = fields.Float(compute="_value_pc", store=True)
    descripcion = fields.Text()
